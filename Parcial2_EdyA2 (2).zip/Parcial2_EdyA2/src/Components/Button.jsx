import React from 'react';

function Button({ onClick, label, customClass = '' }) {
  return (
    <button onClick={onClick} className={customClass}>
      {label}
    </button>
  );
}

export default Button;
