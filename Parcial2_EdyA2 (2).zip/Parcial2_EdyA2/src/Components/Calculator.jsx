// Made by Krsna Gutierrez

import React, { useState, useEffect } from 'react';
import Button from './Button';  // Componente de botón
import Display from './Display';  // Componente Display
import './Calculator.css';

function Calculator() {
  const [input, setInput] = useState('');  
  const [result, setResult] = useState(null);

  useEffect(() => {
    document.title = `Resultado: ${result !== null ? result : 'Calculadora'}`;
  }, [result]);  // Hook para cambiar el título de la página cuando cambia el resultado

  const handleInput = (value) => {
    setInput((prev) => prev + value);
  };

  const calculateResult = () => {
    try {
      const evalResult = Function('"use strict";return (' + input + ')')();
      setResult(evalResult);
    } catch (error) {
      setResult('Error');
    }
  };

  const clearInput = () => {
    setInput('');
    setResult(null);
  };

  return (
    <div className="calculator">
      <Display value={result !== null ? result : input || '0'} />
      <div className="buttons">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map((num) => (
          <Button key={num} onClick={() => handleInput(num.toString())} label={num} />
        ))}
        <Button onClick={() => handleInput('+')} label="+" />
        <Button onClick={() => handleInput('-')} label="-" />
        <Button onClick={() => handleInput('*')} label="*" />
        <Button onClick={() => handleInput('/')} label="/" />
        <Button onClick={clearInput} label="C" />
        <Button onClick={calculateResult} label="=" customClass="calculate" />
      </div>
    </div>
  );

}

export default Calculator;
