import './App.css'

  const title = 'First App'

  const FirstApp = () => {
  return (
    <>
    <h1> New Title </h1>
    <span> 10 </span>
    </>
  )
 }

export default FirstApp

