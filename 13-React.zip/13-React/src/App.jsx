import './App.css'
import React, { useState } from 'react'
import { Memorize } from './components/Memorize'

function App() {
  return (
    <>
      <Memorize />
    </>
  )
}

export default App
