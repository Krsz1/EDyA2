import './App.css'
import React, { useState } from 'react'
import { TodoApp } from './components/TodoApp'

function App() {
  return (
    <>
      <TodoApp />
    </>
  )
}

export default App
