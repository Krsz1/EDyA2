import './App.css'
import React, { useState } from 'react'
import { Father } from './components/Father'

function App() {
  return (
    <>
      <Father />
    </>
  )
}

export default App
