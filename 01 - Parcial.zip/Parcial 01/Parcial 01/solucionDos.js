// Desarrollo punto 2 - krsna Gutierrez

class TreeNode {
    constructor(data) {
      this.data = data;
      this.left = null;
      this.right = null;
    }
  }
  
  class BinaryTree {
    constructor() {
      this.root = null;
    }
  
    insert(data) {
      const newNode = new TreeNode(data);
      if (this.root === null) {
        this.root = newNode;
      } else {
        this.insertNode(this.root, newNode);
      }
    }
  
    insertNode(node, newNode) {
      if (newNode.data < node.data) {
        if (node.left === null) {
          node.left = newNode;
        } else {
          this.insertNode(node.left, newNode);
        }
      } else {
        if (node.right === null) {
          node.right = newNode;
        } else {
          this.insertNode(node.right, newNode);
        }
      }
    }
  
    treeHeight(node) {
      if (node === null) {
        return -1; 
      } else {
        const leftHeight = this.treeHeight(node.left);
        const rightHeight = this.treeHeight(node.right);
        return Math.max(leftHeight, rightHeight) + 1;
      }
    }
  }

// Pruebas:
const tree = new BinaryTree();
tree.insert(5);
tree.insert(3);
tree.insert(7);
tree.insert(2);
tree.insert(4);
tree.insert(6);
tree.insert(8);

console.log("Height of the tree:", tree.treeHeight(tree.root));  