export const CREATE_TODO = '[TODO] ADD TODO';
export const DELETE_TODO = '[TODO] REMOVE TODO';
export const TOGGLE_TODO = '[TODO] TOGGLE TODO';