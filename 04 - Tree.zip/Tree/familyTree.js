// N-ary Trees
class family {
    constructor(name, birthday){
        this.name = name;
        this.birthday = birthday;
        this.children = [];
    }

    familyPreOrden() {
        console.log(this.name);
        this.children.forEach(son => son.familyPreOrden());
    }

    familyPostOrden() {
        this.children.forEach(son => son.familyPostOrden());
        console.log(this.name);
    }

    familyInOrden() {
        if (this.children.length > 0) {
            this.children[0].familyInOrden(); // Primer son
        }
        console.log(this.name);
        for (let i = 1; i < this.children.length; i++) {
            this.children[i].familyInOrden(); // Resto de children
        }
    }
}





