// N.ary family Tree.

class Family {
    constructor(name, birthday) {
        this.name = name;
        this.birthday = birthday;
        this.children = []; 
    }

    // Método para agregar un son
    addChild(son) {
        this.children.push(son);
    }

    // Método para verificar si la persona es una hoja
    isLeaf() {
        return this.children.length === 0;
    }
}

// Funciones para imprimir el árbol en diferentes órdenes
function PreOrder(family) {
    if (!family) return;
    console.log(`${family.name} (${family.birthday})`);
    family.children.forEach(son => PreOrder(son));
}

function PostOrder(family) {
    if (!family) return;
    family.children.forEach(son => PostOrder(son));
    console.log(`${family.name} (${family.birthday})`);
}

function InOrder(family) {
    if (!family) return;
    if (family.children.length > 0) InOrder(family.children[0]);
    console.log(`${family.name} (${family.birthday})`);
    for (let i = 1; i < family.children.length; i++) {
        InOrder(family.children[i]);
    }
}
