import React from "react";
import Login from "./components/Login";
import './App.css'

const App = () => {

  return (
    <div>
      <h1>Welcome to Auth App</h1>
      
        <Login />
    </div>
  );
};

export default App;
