import { createSlice } from '@reduxjs/toolkit';

const initialState = [];

const todosSlice = createSlice({
  name: 'todos',
  initialState,
  reducers: {

    addTodo: (state, action) => {
      const { id, text } = action.payload;

      if (!id || typeof id !== 'number') {
        throw new Error('El ID de la tarea debe ser un número único.');
      }
      if (!text || typeof text !== 'string' || text.trim() === '') {
        throw new Error('El texto de la tarea no puede estar vacío.');
      }

      state.push({ id, text: text.trim() });
    },

    deleteTodo: (state, action) => {
      const todoId = action.payload;

      if (typeof todoId !== 'number') {
        throw new Error('El ID de la tarea a eliminar debe ser un número.');
      }

      return state.filter((todo) => todo.id !== todoId);
    },
  },
});

export const { addTodo, deleteTodo } = todosSlice.actions;

export default todosSlice.reducer;