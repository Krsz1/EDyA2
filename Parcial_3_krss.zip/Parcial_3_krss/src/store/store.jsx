import { configureStore } from '@reduxjs/toolkit';
import pokemonReducer from '../slice/pokemon/pokemonSlice';
import todosReducer from '../slice/todos/todoSlice';

const store = configureStore({
  reducer: {
    pokemon: pokemonReducer,
    todos: todosReducer,
  },

  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false, 
    }),
  
  devTools: process.env.NODE_ENV !== 'production',
});

export default store;
