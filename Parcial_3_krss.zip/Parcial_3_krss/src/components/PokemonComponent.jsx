import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { fetchPokemon } from '../slice/pokemon/pokemonSlice';

import './PokemonComponent.css';

const PokemonComponent = () => {
  const [pokemonId, setPokemonId] = useState(1);
  const dispatch = useDispatch();
  const { data: pokemon, status, error } = useSelector((state) => state.pokemon);

  const handleSearch = () => {
    dispatch(fetchPokemon(pokemonId));
    setPokemonId((prevId) => prevId + 1);
  };

  return (
    <div className="pokemon-container">
      <h2>Look your pokemon</h2>
      <div className="search-bar">
        <button onClick={handleSearch} disabled={status === 'loading'}>
          Search ({pokemonId})
        </button>
      </div>

      {status === 'loading' && <p className="loading">...</p>}
      {error && <p className="error">Error: {error}</p>}
      {pokemon && status === 'succeeded' && (
        <div className="pokemon-details">
          <h3>{pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1)}</h3>
          <img
            src={pokemon.sprites.front_default}
            alt={`Imagen de ${pokemon.name}`}
          />
          <p>weight: {pokemon.weight / 10} kg</p>
          <p>height: {pokemon.height / 10} m</p>
        </div>
      )}
    </div>
  );
};

export default PokemonComponent;
