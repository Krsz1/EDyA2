import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { addTodo, deleteTodo } from '../slice/todos/todoSlice';
import './TodoComponent.css';

const TodoComponent = () => {
  const [text, setText] = useState('');
  const todos = useSelector((state) => state.todos);
  const dispatch = useDispatch();

  const handleAddTodo = () => {
    const trimmedText = text.trim();
    if (trimmedText) {
      dispatch(addTodo({ id: Date.now(), text: trimmedText }));
      setText('');
    }
  };

  const handleKeyDown = (event) => {
    if (event.key === 'Enter') {
      handleAddTodo();
    }
  };

  return (
    <div className="todo-container">
      <h2>To do</h2>
      <div className="todo-input">
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Añade una tarea"
          aria-label="Nueva tarea"
        />
        <button onClick={handleAddTodo} disabled={!text.trim()}>
          Añadir
        </button>
      </div>
      <ul className="todo-list">
        {todos.length === 0 ? (
          <li className="empty-list">There are no pending tasks</li>
        ) : (
          todos.map((todo) => (
            <li key={todo.id} className="todo-item">
              <span className="todo-text">{todo.text}</span>
              <button
                onClick={() => dispatch(deleteTodo(todo.id))}
                className="delete-button"
                aria-label={`Eliminar la tarea: ${todo.text}`}
              >
                Delete
              </button>
            </li>
          ))
        )}
      </ul>
    </div>
  );
};

export default TodoComponent;
