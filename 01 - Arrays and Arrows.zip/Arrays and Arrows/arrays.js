// Made by Krss.

// Apuntes:
let numbers = [1, 2, 3, 4, 5];
console.log('Array inicial:', numbers);

// Function concat
let moreNumbers = [6, 7, 8];
let combined = numbers.concat(moreNumbers);
console.log('Después de concat:', combined);

// Function copyWithin
combined.copyWithin(2, 0, 2);
console.log('Después de copyWithin:', combined);

// Function entries
let iterator = combined.entries();
console.log('Entries:');
for (let entry of iterator) {
  console.log(entry);
}

// Function every
let allAboveZero = combined.every(num => num > 0);
console.log('Todos los números son mayores que 0:', allAboveZero);

// Function fill
combined.fill(9, 0, 2);
console.log('Después de fill:', combined);

// Function filter
let filtered = combined.filter(num => num > 4);
console.log('Después de filter (num > 4):', filtered);

// Function find
let found = combined.find(num => num > 6);
console.log('Encontrar el primer número mayor que 6:', found);

// Function findIndex
let foundIndex = combined.findIndex(num => num > 6);
console.log('Índice del primer número mayor que 6:', foundIndex);

// Function flat
let nestedArray = [1, 2, [3, 4, [5, 6]]];
let flattened = nestedArray.flat(2);
console.log('Array aplanado:', flattened);

// Function forEach
console.log('Usando forEach:');
combined.forEach(num => console.log(num));

// Function includes
let includesNine = combined.includes(9);
console.log('¿Incluye el 9?:', includesNine);

// Function join
let joined = combined.join('-');
console.log('Después de join:', joined);

// Function map
let squared = combined.map(num => num * num);
console.log('Después de map (cuadrados):', squared);

// Function pop
let lastElement = combined.pop();
console.log('Después de pop (último elemento eliminado):', combined);

// Function push
combined.push(10);
console.log('Después de push (añadir 10):', combined);

// Function reduce
let sum = combined.reduce((acc, num) => acc + num, 0);
console.log('Suma de todos los números:', sum);

// Function reverse
combined.reverse();
console.log('Después de reverse:', combined);

// Function shift
let firstElement = combined.shift();
console.log('Después de shift (primer elemento eliminado):', combined);

// Function slice
let sliced = combined.slice(1, 3);
console.log('Después de slice (índice 1 a 3):', sliced);

// Function some
let hasGreaterThanTen = combined.some(num => num > 10);
console.log('¿Hay algún número mayor que 10?:', hasGreaterThanTen);

// Function sort
combined.sort((a, b) => a - b);
console.log('Después de sort:', combined);

// Function splice
combined.splice(2, 1, 99);
console.log('Después de splice (reemplazar el elemento en el índice 2 con 99):', combined);

// Function unshift
combined.unshift(0);
console.log('Después de unshift (añadir 0 al principio):', combined);

// Function values
let valueIterator = combined.values();
console.log('Values:');
for (let value of valueIterator) {
  console.log(value);
}