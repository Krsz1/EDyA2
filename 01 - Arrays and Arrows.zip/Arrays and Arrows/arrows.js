// Made by Krss.

// Regular Function =>
function checkEvenOrOdd(num) {
    if (num % 2 === 0) {
        console.log(num + ' is even.');
    } else {
        console.log(num + ' is odd.');
    }
}

// Arrow Function =>
const checkEvenOrOddArrow = (num) => {
    if (num % 2 === 0) {
        console.log(num + ' is even.');
    } else {
        console.log(num + ' is odd.');
    }
};
